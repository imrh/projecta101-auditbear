Audit Bear is a web application to analyze audit log data from the iVotronic
electronic voting machines and detect various anomalies and problems.

Exported from code.google.com/p/audit-bear
