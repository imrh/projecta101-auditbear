routers = dict(BASE = dict(default_application='audit_bear'))
